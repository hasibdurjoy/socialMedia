import PageBanner from "../src/components/PageBanner";
import SimpleFaq from "../src/components/SimpleFaq";
import Layout from "../src/layout/Layout";
const Faqs = () => {
  return <Layout></Layout>;
};
export default Faqs;
